
def count_in_list(list, string):
    count = 0
    for i in list:
        if i == string:
            count += 1
    return count


