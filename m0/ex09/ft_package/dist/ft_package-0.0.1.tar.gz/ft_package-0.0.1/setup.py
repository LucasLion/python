from setuptools import setup, find_packages

setup(
    name='ft_package',
    version='0.0.1',
    author='llion',
    author_email='llion@42.fr',
    description='A sample test package',
    url='https://github.com/llion/ft_package',
    license='MIT',
    packages=find_packages(),
    include_package_data=True,
)
